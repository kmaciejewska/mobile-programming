package com.example.diceshaker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.Image;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements SensorEventListener, AdapterView.OnItemSelectedListener {
    private static int SHAKE_THRESHOLD = 1;
    private static int NUMBERS_ON_DICE = 6;

    private ImageView dice1;
    private ImageView dice2;
    private ImageView dice3;
    private Spinner choice;
    private List<ImageView> cubes = new ArrayList<>();
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private int numberOfCubes = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dice1 = (ImageView) findViewById(R.id.dice1Img);
        dice2 = (ImageView) findViewById(R.id.dice2Img);
        dice3 = (ImageView) findViewById(R.id.dice3Img);
        setAllInvisible();

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mAccelerometer = (Sensor) mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        choice = findViewById(R.id.choiceSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.choice_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        choice.setAdapter(adapter);
        choice.setOnItemSelectedListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(numberOfCubes != 0) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            float acceleration = (float) Math.sqrt(x * x + y * y + z * z) - SensorManager.GRAVITY_EARTH;

            for(int i = 0; i < numberOfCubes; i++) {
                if(acceleration > SHAKE_THRESHOLD) {
                    generateRandomNumber(cubes.get(i));
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void generateRandomNumber(ImageView dice) {
        Random randomGenerator = new Random();
        int randomNum = randomGenerator.nextInt(NUMBERS_ON_DICE) + 1;
        dice.setImageResource(getResources().getIdentifier("dice" + randomNum, "drawable", "com.example.diceshaker"));
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String[] menuArray = getResources().getStringArray(R.array.choice_array);
        String choice = parent.getItemAtPosition(position).toString();
        String defaultPos = menuArray[0]; //0
        String pos1 = menuArray[1]; //1
        String pos2 = menuArray[2]; //2
        String pos3 = menuArray[3]; //3

        if(choice.equals(defaultPos)) {
            numberOfCubes = 0;
            setAllInvisible();
        }

        if (choice.equals(pos1)) {
            numberOfCubes = Integer.parseInt(pos1);
            showOneDice(dice1);
        } else if (choice.equals(pos2)) {
            numberOfCubes = Integer.parseInt(pos2);
            showSecondDice(dice2);
        } else if (choice.equals(pos3)) {
            numberOfCubes = Integer.parseInt(pos3);
            showThirdDice(dice3);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {}

    public void showDice(ImageView dice) {
        dice.setImageResource(getResources().getIdentifier("dice1", "drawable", "com.example.diceshaker"));
        cubes.add(dice);
    }

    public void showOneDice(ImageView dice1) {
        setAllInvisible();
        cubes.clear();
        showDice(dice1);
    }

    public void showSecondDice(ImageView dice2) {
        showOneDice(dice1);
        showDice(dice2);
    }

    public void showThirdDice(ImageView dice3) {
        showOneDice(dice1);
        showSecondDice(dice2);
        showDice(dice3);
    }

    public void setAllInvisible() {
        dice1.setImageResource(android.R.color.transparent);
        dice2.setImageResource(android.R.color.transparent);
        dice3.setImageResource(android.R.color.transparent);
    }
}