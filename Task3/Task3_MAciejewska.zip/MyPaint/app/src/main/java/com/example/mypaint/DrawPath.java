package com.example.mypaint;

import android.graphics.Color;
import android.graphics.Path;

public class DrawPath {
    private int color;
    private boolean emboss;
    private boolean blur;
    private int strokeWidth;
    private Path path;

    public DrawPath(int color, boolean emboss, int strokeWidth, boolean blur, Path path) {
        this.color = color;
        this.emboss = emboss;
        this.blur = blur;
        this.strokeWidth = strokeWidth;
        this.path = path;
    }

    public int getColor() {
        return color;
    }

    public int getStrokeWidth() {
        return strokeWidth;
    }

    public boolean getEmboss() {
        return emboss;
    }

    public boolean getBlur() {
        return blur;
    }

    public Path getPath() {
        return path;
    }
}