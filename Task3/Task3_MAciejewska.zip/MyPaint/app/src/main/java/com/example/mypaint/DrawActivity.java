package com.example.mypaint;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.drawable.PaintDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;

import static android.view.Window.FEATURE_NO_TITLE;
import static android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN;

public class DrawActivity extends AppCompatActivity implements View.OnClickListener {
    private DrawView drawView;
    private static final int MAX_BRUSH_VAL = 100;
    private static final int BRUSH_SIZE_CIRCLE_BORDER = 4;
    private ImageView currentColorImg;
    private ImageView brushSizeImage;
    private Paint paintBorder;
    private Bitmap preview;
    private int x;
    private int y;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(FLAG_FULLSCREEN, FLAG_FULLSCREEN);
        requestWindowFeature(FEATURE_NO_TITLE);
        setContentView(R.layout.activity_draw);

        drawView = (DrawView) findViewById(R.id.drawView);
        drawView.createBitmap();

        //modes buttons
        Button normalMdBtn = (Button) findViewById(R.id.normalBtn);
        normalMdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawView.normal();
            }
        });

        Button blurMdBtn = (Button) findViewById(R.id.blurBtn);
        blurMdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawView.blur();
            }
        });

        Button embossMdBtn = (Button) findViewById(R.id.embossBtn);
        embossMdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawView.emboss();
            }
        });

        Button clearMdBtn = (Button) findViewById(R.id.clearBtn);
        clearMdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawView.clear();
            }
        });

        Button rubberBtn = (Button) findViewById(R.id.rubberBtn);
        rubberBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawView.rubber();
            }
        });

        //brush size
        SeekBar brushSeekBar = (SeekBar) findViewById(R.id.brushSizeSeekBar);
        brushSizeImage = (ImageView) findViewById(R.id.brushSizeView);
        brushSizeImage.setImageResource(android.R.color.transparent);
        brushSeekBar.setMax(MAX_BRUSH_VAL);
        brushSeekBar.setProgress(drawView.getStrokeWidth());

        brushSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    x = brushSizeImage.getWidth();
                    y = brushSizeImage.getHeight();
                    paintBorder = createPaint(paintBorder);
                    preview = Bitmap.createBitmap(x, y,Bitmap.Config.ARGB_8888);
                    drawOnCanvas(preview, x, y, paintBorder);
                    drawView.changeSize(progress);
                    brushSizeImage.setImageBitmap(preview);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        //colored buttons
        Button black = (Button) findViewById(R.id.buttonBlack);
        Button darkBlue = (Button) findViewById(R.id.buttonDarkBlue);
        Button darkGreen = (Button) findViewById(R.id.buttonDarkGreen);
        Button gray = (Button) findViewById(R.id.buttonGray);
        Button orange = (Button) findViewById(R.id.buttonOrange);
        Button pink = (Button) findViewById(R.id.buttonPink);
        Button purple = (Button) findViewById(R.id.buttonPurple);
        Button red = (Button) findViewById(R.id.buttonRed);
        Button yellow = (Button) findViewById(R.id.buttonYellow);

        black.setOnClickListener(this);
        darkBlue.setOnClickListener(this);
        darkGreen.setOnClickListener(this);
        gray.setOnClickListener(this);
        orange.setOnClickListener(this);
        pink.setOnClickListener(this);
        purple.setOnClickListener(this);
        red.setOnClickListener(this);
        yellow.setOnClickListener(this);

        //current color image
        currentColorImg = (ImageView) findViewById(R.id.currentColorImage);
        currentColorImg.setColorFilter(drawView.getColor());
    }

    //circle of brush size
    public Paint createPaint(Paint paint) {
        paint = new Paint();
        paint.setColor(getResources().getColor(R.color.black));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(BRUSH_SIZE_CIRCLE_BORDER);
        return paint;
    }

    public void drawOnCanvas(Bitmap bitmap, int x, int y, Paint borderPaint) {
        Canvas canvas = new Canvas(bitmap);
        canvas.drawCircle(x / 2f, y / 2f, drawView.getStrokeWidth(), borderPaint);
    }

    //clicking on colors
    @Override
    public void onClick(View v) {
        int color = getResources().getColor(R.color.background);
        switch(v.getId()) {
            case R.id.buttonBlack:
                color = getResources().getColor(R.color.black);
                break;
            case R.id.buttonDarkBlue:
                color = getResources().getColor(R.color.dark_blue);
                break;
            case R.id.buttonDarkGreen:
                color = getResources().getColor(R.color.dark_green);
                break;
            case R.id.buttonGray:
                color = getResources().getColor(R.color.gray);
                break;
            case R.id.buttonOrange:
                color = getResources().getColor(R.color.orange);
                break;
            case R.id.buttonPink:
                color = getResources().getColor(R.color.pink);
                break;
            case R.id.buttonPurple:
                color = getResources().getColor(R.color.purple);
                break;
            case R.id.buttonRed:
                color = getResources().getColor(R.color.red);
                break;
            case R.id.buttonYellow:
                color = getResources().getColor(R.color.yellow);
                break;
        }
        currentColorImg.setColorFilter(color);  //change the square with color image
        drawView.changeColor(color);
    }
}