package com.example.mypaint;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.EmbossMaskFilter;
import android.graphics.MaskFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class DrawView extends View {
    private static int BRUSH_SIZE = 20;
    private final int DEFAULT_BG_COLOR = getResources().getColor(R.color.background);
    private final int DEFAULT_COLOR = getResources().getColor(R.color.red);
    private static final float TOUCH_TOLERANCE = 4;

    private float mX, mY; //coordinates of movement of the finger
    private Path mPath;
    private Paint mPaint;
    private List<DrawPath> paths = new ArrayList<>();
    private Bitmap mBitmap;
    private Canvas mCanvas;
    private Paint mBitmapPaint = new Paint(Paint.DITHER_FLAG); //dithering when blitting, to get a smooth output


    private MaskFilter mEmboss; //blur and emboss are subclasses of MaskFilter
    private MaskFilter mBlur;

    private int currentColor;
    private int lastColor;
    private int strokeWidth;
    private boolean emboss;
    private boolean blur;
    private boolean rubber;

    public DrawView(Context context) {
        this(context, null);
    }

    public DrawView(Context context, AttributeSet attrs) { //constructor used when view is inflated from xml
        super(context, attrs);
        mPaint = new Paint();
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        mPaint.setStrokeCap(Paint.Cap.ROUND);

        mEmboss = new EmbossMaskFilter(new float[] {1, 1, 1}, 0.4f, 8, 3.5f); //light direction, ambient, specular, radius
        mBlur = new BlurMaskFilter(5, BlurMaskFilter.Blur.NORMAL); //radius to extend from originial m., blur style
    }

    public void createBitmap() {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        mBitmap = Bitmap.createBitmap(screenWidth, screenHeight, Bitmap.Config.ARGB_8888); //each pixel stored on 8 bits
        mCanvas = new Canvas(mBitmap);

        strokeWidth = BRUSH_SIZE;
        currentColor = DEFAULT_COLOR;
        lastColor = currentColor;
    }

    public void normal() {
        emboss = false;
        blur = false;
        rubber = false;
        changeColor(lastColor);
    }

    public void emboss() {
        emboss = true;
        blur = false;
        rubber = false;
        changeColor(lastColor);
    }

    public void blur() {
        emboss =  false;
        blur = true;
        rubber = false;
        changeColor(lastColor);
    }

    public void clear() {
        paths.clear();
        normal();
        invalidate();
    }

    public void rubber() {
        normal();
        rubber = true;
        lastColor = currentColor;
        changeColor(DEFAULT_BG_COLOR);
    }

    public int getColor() {
        return currentColor;
    }

    public void changeColor(int color) {
        if(rubber) {
            currentColor = color;   //set white
        } else {
            if(color != lastColor) {    //if difference in color
                currentColor = color;
                lastColor = currentColor;   //save the last color to go back to if used rubber
            } else {
                currentColor = lastColor;
            }
        }
    }

    public void changeSize(int size) {
        strokeWidth = size;
    }

    public int getStrokeWidth() {
        return strokeWidth;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.save();
        mCanvas.drawColor(DEFAULT_BG_COLOR);

        for(DrawPath path : paths) {
            mPaint.setColor(path.getColor());
            mPaint.setStrokeWidth(path.getStrokeWidth());

            if(path.getEmboss()) {
                mPaint.setMaskFilter(mEmboss);
            } else if(path.getBlur()) {
                mPaint.setMaskFilter(mBlur);
            } else {
                mPaint.setMaskFilter(null);
            }

            mCanvas.drawPath(path.getPath(), mPaint);
        }
        canvas.drawBitmap(mBitmap, 0, 0, mBitmapPaint);
        canvas.restore();
    }

    private void touchStart(float x, float y) {
        mPath = new Path();
        DrawPath path = new DrawPath(currentColor, emboss, strokeWidth, blur, mPath);
        paths.add(path);
        mPath.reset();
        mPath.moveTo(x, y);
        mX = x;
        mY = y;
    }

    private void touchMove(float x, float y) {
        float dX = Math.abs(x - mX); //difference between the current and previous position
        float dY = Math.abs(y - mY);

        if(dX >= TOUCH_TOLERANCE || dY >= TOUCH_TOLERANCE) {
            mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2); //quadTo uses a curve/parabola - gives a smoother line
            mX = x; //update the previous position
            mY = y;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN : //the user touches the screen
                touchStart(x, y);
                break;
            case MotionEvent.ACTION_MOVE : //the user moves the finger on the screen
                touchMove(x, y);
                break;
        }
        invalidate();
        return true;
    }
}
